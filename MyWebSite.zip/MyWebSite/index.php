<!DOCTYPE html>
<html lang="fr">

<?php
// Configuration initiale
ini_set('memory_limit', '1024M');
ini_set('max_execution_time', 120);
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Configuration des couleurs
$TextColor = '#000000';

function generateRandomColor() {
    return sprintf('#%06X', mt_rand(0, 0xFFFFFF));
}

function isDarkColor($hexColor) {
    $hexColor = ltrim($hexColor, '#');
    $r = hexdec(substr($hexColor, 0, 2));
    $g = hexdec(substr($hexColor, 2, 2));
    $b = hexdec(substr($hexColor, 4, 2));
    return (0.2126 * $r + 0.7152 * $g + 0.0722 * $b) < 128;
}

$randomColor = generateRandomColor();
if (isDarkColor($randomColor)) {
    $TextColor = '#FFFFFF';
}
$buttonColor = isDarkColor($randomColor) ? '#4a6fa5' : '#2c5e8f';
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Web Site</title>
    <style type="text/css">
        body {
            background-color: <?= $randomColor ?>;
            color: <?= $TextColor ?>;
            font-family: Arial, sans-serif;
            margin: 20px;
            transition: all 0.3s ease;
        }
        .compiler-section {
            margin: 20px 0;
            padding: 20px;
            background-color: rgba(255,255,255,0.1);
            border-radius: 8px;
            max-width: 800px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        #output {
            background-color: rgba(0,0,0,0.1);
            padding: 15px;
            border-radius: 5px;
            margin-top: 15px;
            white-space: pre-wrap;
            font-family: monospace;
            max-height: 500px;
            overflow-y: auto;
            border: 1px solid rgba(255,255,255,0.2);
        }
        button {
            padding: 10px 15px;
            margin: 10px 5px;
            border-radius: 5px;
            cursor: pointer;
            background-color: <?= $buttonColor ?>;
            color: <?= $TextColor ?>;
            border: none;
            font-size: 16px;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .file-list {
            margin: 15px 0;
            background-color: rgba(0,0,0,0.05);
            padding: 10px;
            border-radius: 5px;
            border-left: 4px solid <?= $buttonColor ?>;
        }
        .file-item {
            margin: 8px 0;
            padding: 8px;
            background-color: rgba(0,0,0,0.05);
            border-radius: 3px;
            font-family: monospace;
            display: flex;
            justify-content: space-between;
        }
        .status {
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            font-weight: bold;
        }
        .success {
            background-color: rgba(46, 204, 113, 0.2);
            border-left: 4px solid #2ecc71;
        }
        .error {
            background-color: rgba(231, 76, 60, 0.2);
            border-left: 4px solid #e74c3c;
        }
        .warning {
            background-color: rgba(241, 196, 15, 0.2);
            border-left: 4px solid #f1c40f;
        }
        .input-group {
            margin: 15px 0;
        }
        .input-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: <?= $TextColor ?>;
        }
        .input-group textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            background-color: rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            color: <?= $TextColor ?>;
            font-family: monospace;
            resize: vertical;
            min-height: 100px;
        }
        .compilation-info {
            margin-top: 20px;
            padding: 15px;
            background-color: rgba(0,0,0,0.05);
            border-radius: 5px;
        }
        h1, h2, h3 {
            color: <?= $TextColor ?>;
            margin-top: 0;
        }
        h1 {
            border-bottom: 2px solid <?= $buttonColor ?>;
            padding-bottom: 10px;
        }
    </style>
</head>

<body>
    <h1>My web site !</h1>

    <?php if (file_exists('BA510NA CI.pdf')): ?>
        <button onclick="window.open('BA510NA CI.pdf', 'pdfPopup', 'width=800,height=600')">Documentation PDF</button>
    <?php endif; ?>

    <a href="https://github.com" target="_blank" style="color: <?= $TextColor ?>;">Mon GitHub</a>

    <div class="compiler-section">
        <h2>Compilation du Jeu</h2>
        
        <?php
        // Configuration des fichiers
        $sourceFiles = [
            'main.c' => 2 * 1024 * 1024,
            'character-manager.c' => 2 * 1024 * 1024
        ];
        
        $dataFiles = [
            'game_data/players.csv' => 10 * 1024 * 1024,
            'game_data/enemies.csv' => 10 * 1024 * 1024,
            'game_data/bosses.csv' => 10 * 1024 * 1024,
            'game_data/spells.csv' => 10 * 1024 * 1024
        ];
        
        $executable = 'game';
        $missingFiles = [];
        $sizeErrors = [];
        
        // Vérification des fichiers
        foreach ($sourceFiles as $file => $maxSize) {
            if (!file_exists($file)) {
                $missingFiles[] = $file;
            } elseif (filesize($file) > $maxSize) {
                $sizeInMB = round(filesize($file)/1024/1024, 2);
                $maxSizeInMB = $maxSize/1024/1024;
                $sizeErrors[] = $file . " (" . $sizeInMB . " MB > " . $maxSizeInMB . " MB)";
            }
        }
        
        foreach ($dataFiles as $file => $maxSize) {
            if (!file_exists($file)) {
                $missingFiles[] = $file;
            } elseif (filesize($file) > $maxSize) {
                $sizeInMB = round(filesize($file)/1024/1024, 2);
                $maxSizeInMB = $maxSize/1024/1024;
                $sizeErrors[] = $file . " (" . $sizeInMB . " MB > " . $maxSizeInMB . " MB)";
            }
        }
        
        // Affichage des erreurs
        if (!empty($missingFiles)) {
            echo '<div class="status error">Fichiers manquants:</div>';
            echo '<div class="file-list">';
            foreach ($missingFiles as $file) {
                echo '<div class="file-item">'.$file.'</div>';
            }
            echo '</div>';
        }
        
        if (!empty($sizeErrors)) {
            echo '<div class="status error">Fichiers trop volumineux:</div>';
            echo '<div class="file-list">';
            foreach ($sizeErrors as $error) {
                echo '<div class="file-item">'.$error.'</div>';
            }
            echo '</div>';
        }
        
        // Si tout est OK
        if (empty($missingFiles) && empty($sizeErrors)) {
            echo '<div class="status success">Tous les fichiers sont valides</div>';
            
            // Formulaire
            echo '<form method="post" id="compileForm">';
            echo '<div class="input-group">';
            echo '<label for="user_inputs">Entrées pour le jeu (une par ligne):</label>';
            echo '<textarea id="user_inputs" name="user_inputs" rows="6" placeholder="0  # Choix du personnage\n1  # Première action\n2  # Attaque"></textarea>';
            echo '</div>';
            
            echo '<button type="submit" name="action" value="compile_run">Compiler et Exécuter</button>';
            echo '</form>';
            
            // Traitement
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'compile_run') {
                gc_collect_cycles();
                
                echo '<div class="compilation-info">';
                
                try {
                    // Compilation
                    echo '<h3>Compilation en cours...</h3>';
                    flush();
                    
                    $compileCmd = 'gcc '.implode(' ', array_keys($sourceFiles)).' -o '.$executable.' 2>&1';
                    $compileOutput = [];
                    exec($compileCmd, $compileOutput, $return_var);
                    
                    if ($return_var !== 0) {
                        echo '<div class="status error">Échec de compilation</div>';
                        echo '<div id="output">'.htmlspecialchars(implode("\n", array_slice($compileOutput, 0, 100))).'</div>';
                    } else {
                        echo '<div class="status success">Compilation réussie!</div>';
                        
                        // Exécution avec solution alternative à timeout
                        echo '<h3>Exécution du jeu...</h3>';
                        flush();
                        
                        $inputFile = tempnam(sys_get_temp_dir(), 'gamein');
                        file_put_contents($inputFile, $_POST['user_inputs'] ?? '');
                        
                        // Solution compatible macOS pour limiter le temps d'exécution
                        $runCmd = '(./'.$executable.' < '.escapeshellarg($inputFile).' & sleep 60; kill $! 2>/dev/null) 2>&1';
                        $runOutput = [];
                        exec($runCmd, $runOutput, $return_var);
                        
                        unlink($inputFile);
                        
                        echo '<div id="output">';
                        $outputLines = 0;
                        foreach ($runOutput as $line) {
                            echo htmlspecialchars($line)."\n";
                            if ($outputLines++ % 20 === 0) flush();
                        }
                        echo '</div>';
                    }
                } catch (Throwable $e) {
                    echo '<div class="status error">Erreur: '.htmlspecialchars($e->getMessage()).'</div>';
                }
                
                echo '</div>';
                unset($compileOutput, $runOutput);
                gc_collect_cycles();
            }
        }
        ?>
    </div>

    <script>
        document.getElementById('compileForm').addEventListener('submit', function(e) {
            if (!confirm('Cette opération peut prendre du temps. Continuer ?')) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>
