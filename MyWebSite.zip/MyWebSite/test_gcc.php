<?php
exec('gcc --version 2>&1', $output);
echo "<pre>GCC Version :\n".print_r($output, true)."</pre>";

// Test compilation
file_put_contents('test.c', '#include <stdio.h>\nint main(){printf("OK\\n");return 0;}');
exec('gcc test.c -o test 2>&1 && ./test 2>&1', $output);
echo "<pre>Test compilation :\n".print_r($output, true)."</pre>";
unlink('test.c');
@unlink('test');
?>
