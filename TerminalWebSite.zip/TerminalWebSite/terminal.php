<!DOCTYPE html>
<html>
<head>
    <title>C Program Terminal</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="terminal">
        <div class="output" id="output"></div>
        <div class="input-line">
            <span class="prompt">$</span>
            <input type="text" id="command-input" autofocus>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>
