<?php
// Enable maximum error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');

// Force plain text output for debugging
header('Content-Type: text/plain');

echo "=== DEBUG START ===\n";

$cProgramDir = __DIR__ . '/C_program';
echo "1. C Program Directory: $cProgramDir\n";

if (!is_dir($cProgramDir)) {
    die("ERROR: C_program directory not found\n");
}

echo "2. Changing to directory: $cProgramDir\n";
chdir($cProgramDir);
echo "3. Current directory: " . getcwd() . "\n";

echo "4. Checking for program_output\n";
if (!file_exists('./program_output')) {
    die("ERROR: program_output not found. Please compile with:\n"
      . "cd C_program && gcc main.c character-manager.c -o program_output\n");
}
echo "5. program_output exists\n";

echo "6. Setting up process pipes\n";
$descriptorspec = [
    0 => ["pipe", "r"],  // stdin
    1 => ["pipe", "w"],  // stdout
    2 => ["pipe", "w"]   // stderr
];

echo "7. Attempting to start process\n";
$process = proc_open('./program_output', $descriptorspec, $pipes);

if (!is_resource($process)) {
    die("ERROR: Failed to create process\n");
}
echo "8. Process started successfully\n";

echo "9. Sending initial input (0\\n)\n";
fwrite($pipes[0], "0\n");
fclose($pipes[0]);

echo "10. Reading output\n";
$output = stream_get_contents($pipes[1]);
$errors = stream_get_contents($pipes[2]);

echo "11. Closing pipes\n";
fclose($pipes[1]);
fclose($pipes[2]);

echo "12. Closing process\n";
$returnCode = proc_close($process);

echo "\n=== PROGRAM OUTPUT ===\n";
echo $output;

echo "\n=== PROGRAM ERRORS ===\n";
echo $errors;

echo "\n=== FINAL STATUS ===\n";
echo "Exit code: $returnCode\n";

// For web interface compatibility
if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $returnCode === 0,
        'output' => $output,
        'errors' => $errors
    ]);
}
?>