let gameSession = null;

function displayGameOutput(data) {
    // Clear previous action buttons
    document.querySelector('.action-buttons')?.remove();
    
    // Display output line by line
    data.output.split('\n').forEach(line => {
        if (line.trim()) {
            const className = line.includes('Details of') ? 'game-stats' : 
                             line.includes('Choose action') ? 'game-prompt' : 'game-output';
            addToOutput(line, className);
        }
    });
    
    // Show buttons only if input is required and battle isn't over
    if (data.requires_input && !data.battle_over) {
        showActionButtons();
    }
}

function showActionButtons() {
    const buttons = `
    <div class="action-buttons">
        <button onclick="sendAction(1)">⚔️ Attack</button>
        <button onclick="sendAction(2)">🔮 Spell</button>
        <button onclick="sendAction(3)">📊 Stats</button>
    </div>`;
    document.getElementById('output').insertAdjacentHTML('beforeend', buttons);
}

function sendAction(action) {
    fetch('run_c_program.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: action,
            session_id: gameSession
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            gameSession = data.session_id;
            displayGameOutput(data);
        }
    });
}

// Terminal input handler
document.getElementById('command-input').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        const command = this.value.trim();
        this.value = '';
        addToOutput('$ ' + command, 'command');
        
        if (command === 'run') {
            fetch('run_c_program.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        gameSession = data.session_id;
                        displayGameOutput(data);
                    }
                });
        }
    }
});