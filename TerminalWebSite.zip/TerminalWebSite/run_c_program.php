<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

$cProgramDir = __DIR__ . '/C_program';
$programPath = $cProgramDir . '/program_output';

$input = json_decode(file_get_contents('php://input'), true) ?: [];

try {
    if (!file_exists($programPath)) {
        throw new Exception("Compile first: gcc main.c character-manager.c -o program_output");
    }

    // Determine input sequence
    if (empty($input)) {
        $inputSequence = "0\n"; // First input: select character 0 (Link)
    } else {
        $inputSequence = $input['action']."\n"; // Subsequent inputs
    }

    // Execute program
    $output = shell_exec("cd $cProgramDir && ./program_output <<< " . escapeshellarg($inputSequence) . " 2>&1");

    // Check if battle is over
    $battleOver = (strpos($output, 'health is now -') !== false);
    
    echo json_encode([
        'success' => true,
        'output' => $output,
        'requires_input' => !$battleOver && (strpos($output, 'Choose action:') !== false),
        'battle_over' => $battleOver,
        'session_id' => $input['session_id'] ?? uniqid()
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
