<?php
// Redirect to the terminal interface
header("Location: terminal.php");
exit();
?>